import { app } from "hyperapp"
import { main, text, header, section, h1 } from "@hyperapp/html"
import { focuser } from "./lib/io.js"
import * as AddItem from "./add-item.js"
import * as TodoList from "./todo-list.js"

const todoList = TodoList.wire({
  get: (state) => state.list,
  set: (state, list) => ({ ...state, list })
})

const addItem = AddItem.wire({
  get: (state) => state.newitem,
  set: (state, newitem) => ({ ...state, newitem }),
  onadd: todoList.addItem
})

app({
  init: [
    { newitem: AddItem.init(), list: TodoList.init() },
    focuser(".newitementry input[type=text]")
  ],
  view: (state) =>
    main([
      header(h1(text("Todo App"))),
      main([
        section({ class: "newitementry" }, AddItem.view(addItem.model(state))),
        section({ class: "itemlist" }, TodoList.view(todoList.model(state)))
      ])
    ]),
  node: document.getElementById("app")
})
