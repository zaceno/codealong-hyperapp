import { button, text } from "@hyperapp/html"
import { textInput } from "./lib/view.js"
export default (props) => [
  textInput({
    value: props.value,
    oninput: props.oninput,
    placeholder: "What do you need to do?",
    ondone: props.ondone
  }),
  button({ onclick: props.ondone }, text("+"))
]
