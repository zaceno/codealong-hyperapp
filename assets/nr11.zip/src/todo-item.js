import { input, span, text, button } from "@hyperapp/html"

import { editable } from "./lib/view.js"
export default (props) =>
  editable(
    {
      editing: props.editing,
      value: props.value,
      oninput: props.oninput,
      ondone: props.ondone
    },
    [
      input({
        type: "checkbox",
        checked: props.checked,
        oninput: props.ontoggle
      }),
      span(
        {
          onclick: props.onedit,
          class: { done: props.checked }
        },
        text(props.value)
      ),
      button({ onclick: props.ondelete }, text("X"))
    ]
  )
