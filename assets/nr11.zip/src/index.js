import { app } from "hyperapp"
import { main, text, header, section, h1 } from "@hyperapp/html"
import { focuser } from "./lib/io.js"
import { list } from "./lib/view.js"
import todoItem from "./todo-item.js"
import addItem from "./add-item.js"

const InputNewItem = (state, input) => ({
  ...state,
  newitem: input
})

const AddItem = (state) =>
  !state.newitem
    ? state
    : {
        ...state,
        items: [state.newitem, ...state.items],
        done: [false, ...state.done],
        newitem: null
      }

const ToggleDone = (state, index) => {
  let done = [...state.done]
  done[index] = !done[index]
  return { ...state, done }
}

const Delete = (state, index) => {
  let items = [...state.items]
  let done = [...state.done]
  items.splice(index, 1)
  done.splice(index, 1)
  return { ...state, items, done }
}

const StartEditing = (state, index) => {
  return [
    {
      ...state,
      editing: index
    },
    focuser(".itemlist input[type=text]")
  ]
}

const StopEditing = (state) => ({
  ...state,
  editing: null
})

const InputEditing = (state, input) => {
  let items = [...state.items]
  items[state.editing] = input
  return { ...state, items }
}

app({
  init: [
    { newitem: null, items: [], done: [], editing: null },
    focuser(".newitementry input[type=text]")
  ],
  view: (state) =>
    main([
      header(h1(text("Todo App"))),
      main([
        section(
          { class: "newitementry" },
          addItem({
            value: state.newitem,
            oninput: InputNewItem,
            ondone: AddItem
          })
        ),
        section(
          { class: "itemlist" },
          list({
            items: state.items,
            render: (itemText, index) =>
              todoItem({
                value: state.items[index],
                editing: state.editing === index,
                checked: state.done[index],
                onedit: [StartEditing, index],
                oninput: InputEditing,
                ondone: StopEditing,
                ontoggle: [ToggleDone, index],
                ondelete: [Delete, index]
              })
          })
        )
      ])
    ]),
  node: document.getElementById("app")
})
