import { app } from "hyperapp"
import { main, text, header, section, h1 } from "@hyperapp/html"
import { focuser } from "./lib/io.js"
import { list } from "./lib/view.js"
import todoItem from "./todo-item.js"
import * as AddItem from "./add-item"

const addItem = AddItem.wire({
  get: (state) => state.newitem,
  set: (state, newitem) => ({ ...state, newitem }),
  onadd: (state, newitem) => ({
    ...state,
    items: [newitem, ...state.items],
    done: [false, ...state.done]
  })
})
const ToggleDone = (state, index) => {
  let done = [...state.done]
  done[index] = !done[index]
  return { ...state, done }
}

const Delete = (state, index) => {
  let items = [...state.items]
  let done = [...state.done]
  items.splice(index, 1)
  done.splice(index, 1)
  return { ...state, items, done }
}

const StartEditing = (state, index) => ({
  ...state,
  editing: index
})

const StopEditing = (state) => ({
  ...state,
  editing: null
})

const InputEditing = (state, input) => {
  let items = [...state.items]
  items[state.editing] = input
  return { ...state, items }
}

app({
  init: [
    { newitem: AddItem.init(), items: [], done: [], editing: null },
    focuser(".newitementry input[type=text]")
  ],
  view: (state) =>
    main([
      header(h1(text("Todo App"))),
      main([
        section({ class: "newitementry" }, AddItem.view(addItem.model(state))),
        section(
          { class: "itemlist" },
          list({
            items: state.items,
            render: (itemText, index) =>
              todoItem({
                value: state.items[index],
                editing: state.editing === index,
                checked: state.done[index],
                onedit: [StartEditing, index],
                oninput: InputEditing,
                ondone: StopEditing,
                ontoggle: [ToggleDone, index],
                ondelete: [Delete, index]
              })
          })
        )
      ])
    ]),
  node: document.getElementById("app")
})
