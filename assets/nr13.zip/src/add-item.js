import { button, text } from "@hyperapp/html"
import { textInput } from "./lib/view.js"

export const wire = ({ get, set, onadd }) => {
  const InputNewItem = (state, input) => set(state, input)

  const AddItem = (state) => {
    let value = get(state)
    if (!value) return state
    state = set(state, null)
    state = onadd(state, value)
    return state
  }
  return {
    model: (state) => ({
      value: get(state),
      InputNewItem,
      AddItem
    })
  }
}

export const view = (model) => [
  textInput({
    value: model.value,
    oninput: model.InputNewItem,
    placeholder: "What do you need to do?",
    ondone: model.AddItem
  }),
  button({ onclick: model.AddItem }, text("+"))
]

export const init = () => null
