import todoItem from "./todo-item.js"
import { list } from "./lib/view.js"
import * as todos from "./todo-logic.js"
import { input } from "@hyperapp/html"

export const init = todos.init

export const wire = ({ get, set }) => {
  const map = (fn) => (state, payload) => set(state, fn(get(state), payload))
  return {
    model: (state) => ({
      ...get(state),
      ToggleDone: map(todos.toggleDone),
      Delete: map(todos.dlete),
      StartEditing: map(todos.startEditing),
      StopEditing: map(todos.stopEditing),
      InputEditing: map(todos.inputEditing),
      SetAllDone: map(todos.setAllDone)
    }),
    addItem: map(todos.addItem)
  }
}

export const view = ({ filter, ...model }) =>
  list({
    items: model.items,
    props: (index) => ({
      hidden:
        (filter === "completed" && !model.done[index]) ||
        (filter === "active" && model.done[index])
    }),
    render: (_, index) =>
      todoItem({
        value: model.items[index],
        editing: model.editing === index,
        checked: model.done[index],
        onedit: [model.StartEditing, index],
        oninput: model.InputEditing,
        ondone: model.StopEditing,
        ontoggle: [model.ToggleDone, index],
        ondelete: [model.Delete, index]
      })
  })

export const allCheck = (model) => {
  let allDone = todos.isAllDone(model)

  return input({
    type: "checkbox",
    style: { visibility: model.items.length ? "visible" : "hidden" },
    checked: allDone,
    oninput: [model.SetAllDone, !allDone]
  })
}
