import { app } from "hyperapp"
import { main, text, header, section, h1, footer } from "@hyperapp/html"
import { focuser, lsloader, persister } from "./lib/io.js"
import * as AddItem from "./add-item.js"
import * as TodoList from "./todo-list.js"
import * as Filters from "./filters.js"

const filters = Filters.wire({
  get: (state) => state.filter,
  set: (state, filter) => ({ ...state, filter })
})

const todoList = TodoList.wire({
  get: (state) => state.list,
  set: (state, list) => ({ ...state, list })
})

const addItem = AddItem.wire({
  get: (state) => state.newitem,
  set: (state, newitem) => ({ ...state, newitem }),
  onadd: todoList.addItem
})

app({
  init: [
    { newitem: AddItem.init(), list: TodoList.init(), filter: Filters.init() },
    focuser(".newitementry input[type=text]"),
    lsloader("list-items", (state, data) => ({
      ...state,
      list: data
    }))
  ],
  view: (state, todos = todoList.model(state)) =>
    main([
      header(h1(text("Todo App"))),
      main([
        section({ class: "newitementry" }, [
          TodoList.allCheck(todos),
          ...AddItem.view(addItem.model(state))
        ]),
        section(
          { class: "itemlist" },
          TodoList.view({
            ...todos,
            filter: filters.getFilter(state)
          })
        ),
        footer([Filters.menu(filters.model(state))])
      ])
    ]),
  subscriptions: (state) => [
    persister("list-items", state.list),
    ...Filters.subs(filters.model(state))
  ],
  node: document.getElementById("app")
})
