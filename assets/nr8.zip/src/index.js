import { app } from 'hyperapp'
import {
  main,
  text,
  input,
  button,
  ul,
  li,
  span,
  header,
  section,
  h1,
} from '@hyperapp/html'

const withEnterKey = action => (state, payload) => {
  if (payload.key && payload.key === 'Enter') return [action, payload]
  return state
}

const withTargetValue = action => (state, payload) => {
  if (payload.target && payload.target.value)
    return [action, payload.target.value]
  return state
}

const InputNewItem = (state, input) => ({
  ...state,
  newitem: input,
})

const AddItem = state =>
  !state.newitem
    ? state
    : {
        ...state,
        items: [state.newitem, ...state.items],
        done: [false, ...state.done],
        newitem: null,
      }

const ToggleDone = (state, index) => {
  let done = [...state.done]
  done[index] = !done[index]
  return { ...state, done }
}

const Delete = (state, index) => {
  let items = [...state.items]
  let done = [...state.done]
  items.splice(index, 1)
  done.splice(index, 1)
  return { ...state, items, done }
}

const StartEditing = (state, index) => ({
  ...state,
  editing: index,
})

const StopEditing = state => ({
  ...state,
  editing: null,
})

const InputEditing = (state, input) => {
  let items = [...state.items]
  items[state.editing] = input
  return { ...state, items }
}

app({
  init: { newitem: null, items: [], done: [], editing: null },
  view: state =>
    main([
      header(h1(text('Todo App'))),
      main([
        section({ class: 'newitementry' }, [
          input({
            type: 'text',
            value: state.newitem,
            oninput: withTargetValue(InputNewItem),
            placeholder: 'What do you need to do?',
            onkeypress: withEnterKey(AddItem),
          }),
          button({ onclick: AddItem }, text('+')),
        ]),
        section({ class: 'itemlist' }, [
          ul(
            state.items.map((itemText, index) =>
              li(
                state.editing === index
                  ? input({
                      type: 'text',
                      value: state.items[index],
                      oninput: withTargetValue(InputEditing),
                      onblur: StopEditing,
                      onkeypress: withEnterKey(StopEditing),
                    })
                  : [
                      input({
                        type: 'checkbox',
                        checked: state.done[index],
                        oninput: [ToggleDone, index],
                      }),
                      span(
                        {
                          onclick: [StartEditing, index],
                          class: { done: state.done[index] },
                        },
                        text(itemText)
                      ),
                      button({ onclick: [Delete, index] }, text('X')),
                    ]
              )
            )
          ),
        ]),
      ]),
    ]),
  node: document.getElementById('app'),
})
